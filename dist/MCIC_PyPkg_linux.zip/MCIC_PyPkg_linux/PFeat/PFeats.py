from atc_wp import atc_wp as atc
from boc_wp import boc_wp as boc
from ddor_wp import ddor_wp as ddor
from pcp_wp import pcp_wp as pcp
from rri_wp import rri_wp as rri
from sep_wp import sep_wp as sep
from ser_wp import ser_wp as ser
from se_wp import se
import random, string
import pandas as pd
import numpy as np
import os, sys

def write_seq_to_file(seq):

	rand = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(7))
	with open('temp/'+rand+'.fasta', 'w') as temp_seq_file:
		temp_seq_file.write(seq)
	return 'temp/' + rand + '.fasta'


def read_res_from_file(file):

	return pd.read_csv(file)


# arguments for all features: "file, outt"
def Pfeat(seq, feat):
	
	inp_file = write_seq_to_file(seq)
	out_file = inp_file.replace('fasta','csv')
	
	if feat == 'atc':
		atc(inp_file, out_file)
		val = read_res_from_file(out_file)
		val.columns = ['atc_'+str(val.columns[i]) for i in range(len(val.columns))]

	elif feat == 'boc':
		boc(inp_file, out_file)
		val = read_res_from_file(out_file)
		val.columns = ['boc_'+str(val.columns[i]) for i in range(len(val.columns))]

	elif feat == 'ddor':
		ddor(inp_file, out_file)
		val = read_res_from_file(out_file)
		val = val.drop('Unnamed: 20', axis=1)
		val.columns = ['ddor_'+str(val.columns[i]) for i in range(len(val.columns))]

	elif feat == 'pcp':
		val = pd.DataFrame(np.array(pcp(inp_file, out_file)))
		new_header = list(val.iloc[0])
		val = val[1:]
		val.columns = new_header
		val = val.reset_index()
		val = val.drop('index', axis=1)
		val.columns = ['pcp_'+str(val.columns[i]) for i in range(len(val.columns))]

		
	elif feat == 'rri':
		rri(inp_file, out_file)
		val = read_res_from_file(out_file)
		val = val.drop('Unnamed: 20', axis=1)
		val.columns = ['rri_'+str(val.columns[i]) for i in range(len(val.columns))]

	elif feat == 'sep':
		val = pd.DataFrame(np.array(sep(inp_file, out_file)))
		new_header = list(val.iloc[0])
		val = val[1:]
		val.columns = new_header
		val = val.reset_index()
		val = val.drop('index', axis=1)
		val.columns = ['sep_'+str(val.columns[i]) for i in range(len(val.columns))]

	elif feat == 'ser':
		val = pd.DataFrame(np.array(ser(inp_file, out_file)))
		val.columns = ['ser_'+str(i) for i in range(val.shape[1])]

	elif feat == 'se':
		val = pd.DataFrame(np.array(se(inp_file, out_file)))
		val.columns = ['Shannon Entropy']

	os.remove(inp_file)
	os.remove(out_file)

	return val

def Extract_all(seq):
	feats = ['atc', 'boc', 'ddor', 'pcp', 'rri', 'sep', 'ser', 'se']
	results = []
	for f in feats:
		results.append(Pfeat(seq, f))
	return pd.concat(results, axis=1)


if __name__ == "__main__":
	# seq = 'MKVVAPKPFTFEGGDRAVLLLHGFTGTTADVRMIGRHLQKEGYTCHAPLYKGHGVPPEELVHTGPEDWWKDVEAGYNYLKEKGHEEIAVCGLSLGGVFSLKIGYTLPVKGIVPMCAPVRPKTEDAMYKGVLAYAREYKKREQKSDDVINQEMEAFKPMGTLSALGELIQDVHNHLDHIYSPTFVVQARNDEMIDVESANIIHGQIESDEKSLKWYEESGLVITLDKEKEQLHEDILQFLEGLDWTVDPNSSSVDKLAAALEHHHHHH'
	# print(Extract_all(seq))

	if sys.argv[1] == 'Extract_all':
		seq = sys.argv[2]
		rand = sys.argv[3]
		resdf = Extract_all(seq)
		resdf.to_csv('temp/' + rand + '.csv')

		